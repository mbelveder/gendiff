import json
import yaml
import argparse


def main():
    parser = argparse.ArgumentParser(
        description='Compares two configuration files and shows a difference.',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    parser.add_argument('json_path')
    parser.add_argument('yaml_path')
    args = parser.parse_args()

    # Read the JSON file
    with open(args.json_path, 'r') as json_file:
        data = json.load(json_file)

    # Write the data to a YAML file
    with open(args.yaml_path, 'w') as yaml_file:
        yaml.dump(data, yaml_file, default_flow_style=False)


if __name__ == "__main__":
    main()
